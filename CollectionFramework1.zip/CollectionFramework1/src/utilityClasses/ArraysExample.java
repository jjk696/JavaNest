package utilityClasses;

import java.util.Arrays;

public class ArraysExample {
    public static void main(String[] args) {
        int[] arr = {10, 5, 20};

        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr)); // [5, 10, 20]

        int index = Arrays.binarySearch(arr, 10);
        System.out.println("Index of 10: " + index);
    }
}

