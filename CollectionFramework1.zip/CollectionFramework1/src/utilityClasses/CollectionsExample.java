package utilityClasses;

import java.util.*;

public class CollectionsExample {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>(Arrays.asList(30, 10, 20));

        Collections.sort(list);
        System.out.println(list); // [10, 20, 30]

        Collections.reverse(list);
        System.out.println(list); // [30, 20, 10]

        System.out.println(Collections.max(list)); // 30
    }
}
