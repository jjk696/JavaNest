package mapInterface3;

//Maintains insertion order.
import java.util.LinkedHashMap;

public class LinkedHashMapExample {
    public static void main(String[] args) {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<>();

        map.put(1, "Java");
        map.put(2, "Spring");
        map.put(3, "Hibernate");

        System.out.println(map);
    }
}
