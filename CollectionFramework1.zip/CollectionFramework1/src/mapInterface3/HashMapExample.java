package mapInterface3;


//Stores key-value pairs.
//Keys are unique; 
//values can be duplicated.
//Unordered key-value pairs.

import java.util.HashMap;

public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Integer, String> map = new HashMap<>();

        map.put(1, "Java");
        map.put(2, "Spring");
        map.put(3, "Hibernate");

        System.out.println(map.get(2)); // Spring
        map.remove(1);
        System.out.println(map);
    }
}
