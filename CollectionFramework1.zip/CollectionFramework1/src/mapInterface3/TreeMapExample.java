package mapInterface3;

import java.util.TreeMap;
//Sorted map in natural order of keys.
public class TreeMapExample {
    public static void main(String[] args) {
        TreeMap<Integer, String> map = new TreeMap<>();

        map.put(3, "Hibernate");
        map.put(1, "Java");
        map.put(2, "Spring");

        System.out.println(map); // {1=Java, 2=Spring, 3=Hibernate}
    }
}
