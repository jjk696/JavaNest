package setInterface2;

import java.util.LinkedHashSet;

public class LinkedHashSetExample {
    public static void main(String[] args) {
        LinkedHashSet<Integer> set = new LinkedHashSet<>();

        set.add(10);
        set.add(20);
        set.add(30);
        set.add(10); // Duplicate ignored

        System.out.println(set); // [10, 20, 30]
    }
}
