package setInterface2;


//No duplicates allowed.
//Unordered or sorted, depending on the implementation.

import java.util.HashSet;

public class HashSetExample {
    public static void main(String[] args) {
        HashSet<String> set = new HashSet<>();

        set.add("Java");
        set.add("Python");
        set.add("Java"); // Duplicate, ignored

        for (String lang : set) {
            System.out.println(lang);
        }
    }
}
