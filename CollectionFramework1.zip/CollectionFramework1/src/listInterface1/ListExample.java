package listInterface1;

import java.util.ArrayList;
import java.util.List;


/* list interface extends cllection,
 * allow duplicates, elements ordered,
 */
public class ListExample {
public static void main(String arg[]) {
	
	List<String> list= new ArrayList<>();
		list.add("apple");
		list.add("Mango");
		list.add("orange");
		list.add("Kiwi");
		
		System.out.println(list);
		
		List<String> list1 = new ArrayList<>();
		list1.add("Java");
		list1.add("Python");

		for (int i = 0; i < list1.size(); i++) {
		    System.out.println(list1.get(i));
		}

		
		
	}
}

