package listInterface1;

import java.util.LinkedList;

public class LinkedListExample {
    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();

        list.add("Java");
        list.add("Python");
        list.add("C++");

        list.addFirst("C");
        list.addLast("JavaScript");

        System.out.println(list);

        list.removeFirst();
        list.removeLast();
        System.out.println(list);
    }
}
