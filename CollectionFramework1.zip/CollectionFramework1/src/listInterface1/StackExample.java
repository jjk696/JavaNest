package listInterface1;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();

        stack.push("Java");
        stack.push("Spring Boot");
        stack.push("Microservices");

        System.out.println(stack.peek()); // Microservices
        stack.pop();
        System.out.println(stack.peek()); // Spring Boot
    }
}
