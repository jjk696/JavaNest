package listInterface1;

import java.util.ArrayList;

/*
 * --ArrayList can grow and shrink dynamically as elements are added or removed.
---Unlike arrays, ArrayLists do not have a fixed size
---Elements are stored in the order they are inserted.
---Accessing elements using an index preserves their order.
---ArrayList can store duplicate values, unlike sets.
*/

public class ArrayListExample {
public static void main (String args[]) {
	
	ArrayList<Integer> a=new ArrayList<>();
	a.add(23);
	a.add(43);
	a.add(54);
	a.add(87);
	System.out.println("list of all numbers "+a);
	
	System.out.println(a.get(3));
	
	System.out.println("removing elements "+a.remove(3));
	System.out.println(a);
	
        // Creating an ArrayList of String type
        ArrayList<String> fruits = new ArrayList<>();

        // Adding elements to the ArrayList
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");

        // Displaying the ArrayList
        System.out.println("Fruits List: " + fruits);

        // Accessing an element using get() method
        System.out.println("First Fruit: " + fruits.get(0));

        // Modifying an element using set() method
        fruits.set(1, "Blueberry");
        System.out.println("After Modification: " + fruits);

        // Removing an element using remove() method
        fruits.remove(2);
        System.out.println("After Removing an Element: " + fruits);

        // Checking if an element exists using contains() method
        if (fruits.contains("Apple")) {
            System.out.println("Apple is in the list.");
        } else {
            System.out.println("Apple is not in the list.");
        }

        // Iterating through ArrayList using a for loop
        System.out.println("Iterating through the list:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }

        // Getting the size of the ArrayList
        System.out.println("Size of the ArrayList: " + fruits.size());

        // Clearing the ArrayList
        fruits.clear();
        System.out.println("After Clearing: " + fruits);
    }
}



