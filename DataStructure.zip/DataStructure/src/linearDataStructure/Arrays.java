package linearDataStructure;


//Data is stored sequentially.
//Fixed-size collection of elements.
//Access using an index.
public class Arrays {
	
	    public static void main(String[] args) {
	        int[] arr = {10, 20, 30, 40, 50};

	        // Accessing elements
	        System.out.println(arr[2]); // 30

	        // Iterating through the array
	        for (int i = 0; i < arr.length; i++) {
	            System.out.print(arr[i] + " ");
	        }
	    }
	}


