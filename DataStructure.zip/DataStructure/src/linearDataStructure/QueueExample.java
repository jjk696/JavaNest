package linearDataStructure;

import java.util.LinkedList;
import java.util.Queue;

/*FIFO (First In, First Out).
Operations:
offer() → Add element
poll() → Remove element
peek() → Get front element*/


public class QueueExample {
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Adding elements
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);

        // Accessing elements
        System.out.println(queue.peek()); // 10
        System.out.println(queue.poll()); // 10
        System.out.println(queue.poll()); // 20
    }
}
