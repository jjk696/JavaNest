package linearDataStructure;

import java.util.Stack;

/*LIFO (Last In, First Out).
Operations:
push() → Add element
pop() → Remove element
peek() → Get top element*/

public class StackExample {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Pushing elements
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Peek and Pop
        System.out.println(stack.peek()); // 30
        System.out.println(stack.pop());  // 30
        System.out.println(stack.pop());  // 20
    }
}
