package sortingAlgorithms;

public class SelectionSort {

}
