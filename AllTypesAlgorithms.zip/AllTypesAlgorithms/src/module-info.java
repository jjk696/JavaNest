/**
 * 
 */
/**
 * 
 */
module AlgorithmsTypes {
}